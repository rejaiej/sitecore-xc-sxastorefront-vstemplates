﻿namespace $rootnamespace$
{
    using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;

    public interface $safeitemname$
    {
        object GetAllItems(IRendering rendering);
    }
}
