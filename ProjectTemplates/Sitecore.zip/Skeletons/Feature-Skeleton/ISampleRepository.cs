﻿namespace $safeprojectname$.Repositories
{
    using Sitecore.XA.Foundation.SitecoreExtensions.Interfaces;

    using Models;

    public interface $sampleIRepositoryName$
    {
        $sampleRenderingModelName$ GetAllItems(IRendering rendering);
    }
}
